pub use graph::{Network, ScheTree, ScheduleTrees, algo};

use std::fs;
use std::error::Error;

use petgraph::Direction;
use serde::{Deserialize, Serialize};
use quick_xml::{se, de};

#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct Algo {
    #[serde(rename = "@name")]
    name: String,
    #[serde(rename = "@proto")]
    proto: String,
    #[serde(rename = "@nchannels")]
    nchannels: usize,
    #[serde(rename = "@nchunksperloop")]
    nchunksperloop: usize,
    #[serde(rename = "@ngpus")]
    ngpus: usize,
    #[serde(rename = "@coll")]
    coll: String,
    #[serde(rename = "@inplace")]
    inplace: u32,
    #[serde(rename = "@outofplace")]
    outofplace: u32,
    #[serde(rename = "@minBytes")]
    min_bytes: u32,
    #[serde(rename = "@maxBytes")]
    max_bytes: u32,
    #[serde(default, rename = "gpu")]
    pub gpus: Vec<Gpu>,
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct Gpu {
    #[serde(rename = "@id")]
    pub id: usize,
    #[serde(rename = "@i_chunks")]
    i_chunks: usize,
    #[serde(rename = "@o_chunks")]
    o_chunks: usize,
    #[serde(rename = "@s_chunks")]
    s_chunks: usize,
    #[serde(default, rename = "tb")]
    pub ports: Vec<Port>,
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct Port {
    #[serde(rename = "@id")]
    id: usize,
    #[serde(rename = "@send")]
    pub send: isize,
    #[serde(rename = "@recv")]
    recv: isize,
    #[serde(rename = "@chan")]
    chan: usize,
    #[serde(default, rename = "step")]
    pub steps: Vec<Step>,
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct Step {
    #[serde(rename = "@s")]
    s: usize,
    #[serde(rename = "@type")]
    transact_type: String,
    #[serde(rename = "@srcbuf")]
    srcbuf: String,
    #[serde(rename = "@srcoff")]
    srcoff: usize,
    #[serde(rename = "@dstbuf")]
    dstbuf: String,
    #[serde(rename = "@dstoff")]
    dstoff: usize,
    #[serde(rename = "@cnt")]
    cnt: usize,
    #[serde(rename = "@depid")]
    depid: isize,
    #[serde(rename = "@deps")]
    deps: isize,
    #[serde(rename = "@hasdep")]
    hasdep: u32,
}

pub fn build(fname: &str) -> Result<Vec<ScheduleTrees>, Box<dyn Error>> {
    let schedule_file = fs::read_to_string(fname)?;
    let schedule: Algo = de::from_str(&schedule_file)?;
    let num_nodes: usize = schedule.gpus.len();
    let num_chunks: usize = schedule.nchunksperloop / num_nodes;
    let mut sche_trees: Vec<ScheduleTrees> = Vec::new();
    let mut captured_edges: usize = 0;
    sche_trees.resize_with(
        num_chunks,
        || {
            let mut tree = ScheduleTrees::new();
            tree.resize_with(num_nodes, || Some(ScheTree::new()));
            tree
        },
    );
    for sche in sche_trees.iter_mut() {
        for (i, tree) in sche.iter_mut().enumerate() {
            tree.as_mut().unwrap().add_node(i);
        }
    }

    for gpu in schedule.gpus {
        let from_node = gpu.id;
        for port in gpu.ports {
            // only look at broadcast schedule, completely mirror of recv
            if port.send >= 0 {
                let to_node: usize = port.send as usize;
                for step in port.steps {
                    let chunk_step = step.srcoff / num_nodes;
                    let chunk_node = step.srcoff % num_nodes;
                    let Some(ref mut tree) = sche_trees[chunk_step][chunk_node] 
                        else { panic!("Tree {}-{} doesn't exist!", chunk_step, chunk_node); };
                    assert!(!tree.contains_edge(from_node, to_node), "Duplicating edge in schedule!");
                    tree.add_edge(from_node, to_node, step.s);
                    captured_edges += 1;
                }
            }
        }
    }
    if captured_edges != num_nodes * (num_nodes - 1) * sche_trees.len() {
        println!("WARNING: Schedule are Not Trees!");
    }
    Ok(sche_trees)
}

/// Outputs schedule to an MSCCL XML file
pub fn write_schedule(
    fname: &str,
    sche_trees: &[ScheduleTrees],
    network: &Network,
    ag_start_t: usize,
) -> Result<(), Box<dyn Error>> {
    let num_nodes = network.node_count();
    let num_chunks = sche_trees.len();
    let mut ccl_sch = Algo {
        name: "l3sstree".to_string(),
        proto: "Simple".to_string(),
        nchannels: 1,
        nchunksperloop: num_nodes * num_chunks,
        ngpus: network.node_count(),
        coll: "allgather".to_string(),
        inplace: 1,
        outofplace: 0,
        min_bytes: 0,
        max_bytes: 0,
        gpus: Vec::new(),
    };
    for node in 0..num_nodes {
        let mut ports: Vec<Port> = Vec::new();
        for (_, to_node, _) in network.edges_directed(node, Direction::Outgoing) {
            let port = Port {
                id: ports.len(),
                send: to_node.try_into().unwrap(),
                recv: -1,
                chan: 0,
                steps: Vec::new(),
            };
            ports.push(port);
        }
        for (from_node, _, _) in network.edges_directed(node, Direction::Incoming) {
            let port = Port {
                id: ports.len(),
                send: -1,
                recv: from_node.try_into().unwrap(),
                chan: 0,
                steps: Vec::new(),
            };
            ports.push(port);
        }
        let gpu = Gpu {
            id: node,
            i_chunks: 0,
            o_chunks: ccl_sch.nchunksperloop,
            s_chunks: 0,
            ports: ports,
        };
        ccl_sch.gpus.push(gpu);
    }

    let time_range = sche_trees.iter().map(|sche| get_step_range(sche)).collect::<Vec<_>>();
    let max_time = time_range.iter().map(|srange| (*srange).1).max().unwrap();

    for time in 0..(max_time + 1) {
        for (i, sche) in sche_trees.iter().enumerate() {
            if time < time_range[i].0 || time > time_range[i].1 { continue; }
            for (schunk, sch_o) in sche.iter().enumerate() {
                let sch = sch_o.as_ref().unwrap();
                for (from_node, to_node, edge_t) in sch.all_edges() {
                    if *edge_t != time { continue; }
                    // from_node send
                    let mut send_step = Step {
                        s: time,
                        transact_type: "s".to_string(),
                        srcbuf: "o".to_string(),
                        srcoff: i * num_nodes + schunk,
                        dstbuf: "o".to_string(),
                        dstoff: i * num_nodes + schunk,
                        cnt: 1,
                        depid: -1,
                        deps: -1,
                        hasdep: 0,
                    };
                    // find parent node for depid and deps
                    if let Some((parent_node, _, _)) = 
                        sch.edges_directed(from_node, Direction::Incoming).next()
                    {
                        for port in ccl_sch.gpus[from_node].ports.iter() {
                            if port.recv != parent_node as isize { continue; }
                            for parent_step in port.steps.iter() {
                                if parent_step.dstoff == i * num_nodes + schunk {
                                    send_step.depid = port.id as isize;
                                    send_step.deps = parent_step.s as isize;
                                    break;
                                }
                            }
                        }
                    }
                    for portid in 0..ccl_sch.gpus[from_node].ports.len() {
                        if ccl_sch.gpus[from_node].ports[portid].send == to_node as isize {
                            ccl_sch.gpus[from_node].ports[portid].steps.push(send_step);
                            break;
                        }
                    }

                    // to_node receive
                    let hasdep: u32 = match sch.edges_directed(to_node, Direction::Outgoing).next() {
                        Some(_) => 1,
                        None => 0,
                    };
                    let recv_step = Step {
                        s: time,
                        transact_type: (if time < ag_start_t { "r" } else { "g" }).to_string(),
                        srcbuf: "o".to_string(),
                        srcoff: i * num_nodes + schunk,
                        dstbuf: "o".to_string(),
                        dstoff: i * num_nodes + schunk,
                        cnt: 1,
                        depid: -1,
                        deps: -1,
                        hasdep: hasdep,
                    };
                    for portid in 0..ccl_sch.gpus[to_node].ports.len() {
                        if ccl_sch.gpus[to_node].ports[portid].recv == from_node as isize {
                            ccl_sch.gpus[to_node].ports[portid].steps.push(recv_step);
                            break;
                        }
                    }
                }
            }
        }
    }
    fs::write(fname, &se::to_string(&ccl_sch)?)?;
    Ok(())
}

fn get_step_range(sche: &ScheduleTrees) -> (usize, usize) {
    let mut min_step: usize = usize::MAX;
    let mut max_step: usize = 0;
    for sch_o in sche.iter() {
        let sch = sch_o.as_ref().unwrap();
        for (_, _, step) in sch.all_edges() {
            if *step > max_step { max_step = *step; }
            if *step < min_step { min_step = *step; }
        }
    }
    (min_step, max_step)
}
